const { Client } = require('pg');

const cliente = new Client({
    user: "postgres",
    password: "1308",
    host: "127.0.0.1",
    port: 5433,
    database: "feira"
});

var DinherioSuficiente;
var valor_produto;
var produto_id;
var id_validos = [];
// Variáveis do usuário
var email = "leojn132013@gmail.com";
var senha = "senhaadm";

const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function connectClient(){
    try {
        await cliente.connect();
       // console.log("Cliente Conectado")
    } catch (error) {
        console.log(error)
        rl.close();
    }
}

async function obterReceitas(table) {
    try {
       /* if(table){
          await cliente.connect();
        }*/
        var resultado = await cliente.query("SELECT SUM(valor) FROM receitas WHERE jogador_id = (SELECT id FROM jogador WHERE email = $1 AND senha = $2)", [email, senha]);
        var receitas_completas = await cliente.query("SELECT jogador.apelido AS usuario, jogo.nome as Nome_do_jogo, receitas.valor, to_char(receitas.data, 'DD/MM/YYYY HH24:MI:SS') as data FROM receitas INNER JOIN jogador ON jogador.id = receitas.jogador_id INNER JOIN jogo ON jogo.id = receitas.jogo_id where receitas.jogador_id = (select id from jogador where email = 'leojn132013@gmail.com'and senha = 'senhaadm');");
        //console.log(parseInt(resultado.rows[0].sum));
        if(!table){
        return parseInt(resultado.rows[0].sum)
        }else if(table){
          return receitas_completas;
        }
    } catch (ex) {
        console.log("Ocorreu um erro ao obter as receitas, o erro é: " + ex);
        return 0;
    }
}

async function obterDespesas(table) {
    try {
      /*if(table){
        await cliente.connect();
      }*/
        var resultado = await cliente.query("SELECT SUM(valor) FROM despesas WHERE jogador_id = (SELECT id FROM jogador WHERE email = $1 AND senha = $2)", [email, senha]);
        var despesas_completas = await cliente.query("SELECT jogador.apelido AS usuario, produto.descricao as produto, despesas.valor, to_char(despesas.data, 'DD/MM/YYYY HH24:MI:SS') as data FROM despesas INNER JOIN jogador ON jogador.id = despesas.jogador_id INNER JOIN produto ON produto.id = despesas.produto_id where despesas.jogador_id = (select id from jogador where email = 'leojn132013@gmail.com'and senha = 'senhaadm');");
        //console.log(parseInt(resultado.rows[0].sum));
        if(!table){
          return parseInt(resultado.rows[0].sum)
          }else if(table){
            return despesas_completas;
          }
    } catch (ex) {
        console.log("Ocorreu um erro ao obter as despesas, o erro é: " + ex);
        return 0;
    }
}

async function getProdutos() {
    try {
        //await cliente.connect();
        var resultado = await cliente.query("SELECT * FROM produto WHERE id IN (SELECT produto_id FROM estoque WHERE quantidade > 0);");
        console.table(resultado.rows);
        //id_validos = (await cliente.query("select id from produto")).rows;
        //console.log(parseInt(id_validos))
        id_validos = [];
        resultado.rows.forEach(row => {
            id_validos.push(parseInt(row.id, 10));
        });

        //console.log(id_validos);
        
    } catch (ex) {
        console.log("Ocorreu um erro no getProdutos, o erro é:" + ex);
    }
}

async function Comprar_Produto(id) {
    try {
        var valor_produto_bruto = await cliente.query("select valor from produto where id =" + id);
        valor_produto = parseInt(valor_produto_bruto.rows[0].valor);
        console.log("O valor do produto é de " + valor_produto + " Tijolinhos");

        const receitas = await obterReceitas(false);
        const despesas = await obterDespesas(false);

        console.log("Seu saldo atual é de " + (receitas - despesas) + " Tijolinhos");


        if ((receitas - despesas) > valor_produto) {
            DinherioSuficiente = true;
        } else {
            DinherioSuficiente = false;
            console.log("Você não tem tijolinhos suficientes para finalizar a compra");
            rl.close()
        }

    } catch (ex) {
        console.log("Ocorreu um erro no Comprar_Produto, o erro é:" + ex);
    }
}

async function Finalizar_Compra() {
  try {
    const dataAtual = new Date(); // Obtém a data e hora atuais
    const dataFormatada = formatarData(dataAtual);
      await cliente.query("insert into despesas(jogador_id,produto_id,valor,data) values((select id from jogador where email = '"+email+"'and senha = '"+senha+"'),"+produto_id+","+valor_produto+",'"+dataFormatada+"');");
      await cliente.query("update estoque set quantidade = quantidade - 1 where produto_id ="+produto_id+" ;")
      const receitas_final = await obterReceitas(false);
      const despesas_final = await obterDespesas(false);
      console.log("Seu saldo atual é de: "+(receitas_final-despesas_final)+" Tijolinhos")
      cliente.end();
      rl.close();
        
    } catch (ex) {
      console.log("Ocorreu um erro no finalizar compra, o erro é:" + ex);
    }

}

function escolha() {
    rl.question('Você Deseja: Comprar_Produto(1), Ver_Receitas(2), Ver_Despesas(3), Ver_Extrato(4), Sair(5)? \nR: ', async (userInput) => {
        if (userInput === "1") {

            await getProdutos();
            console.log("Insira o ID do Produto");
            rl.question('R:', async (ID_Produto) => {
                produto_id = parseInt(ID_Produto);
                if(id_validos.includes(produto_id)){
                    console.log(produto_id)
                    await Comprar_Produto(produto_id);
                    if (DinherioSuficiente) {
                    rl.question('Você deseja Concluir a compra? Sim(1) Não(2) \nR: ', async (confirmacao) => {
                        if (confirmacao === "1") {
                            await Finalizar_Compra();
                            rl.close();
                        } else {
                            rl.question('Você deseja: Sair(1) ou Voltar_ao_Início(2)? \nR: ', (resposta_do_usr) => {
                                if (resposta_do_usr === "2") {
                                    escolha();
                                } else {
                                    rl.close();
                                }
                            });
                        }
                    });
                }}else{
                    console.log("\x1b[34mID Inválido");
                    console.log("\x1b[0m")
                    //cliente.;
                    escolha();
                }
            });
        } else if (userInput === "2") {
          obterReceitas(true)
          .then((resultado) => {
              console.table(resultado.rows);
              cliente.end();
              rl.close();
          })
        } else if (userInput === "3") {
          obterDespesas(true)
          .then((resultado) => {
              console.table(resultado.rows);
              cliente.end();
              rl.close();
          })
          .catch((error) => console.error(error));
        }else if(userInput === "4"){
            console.log("Ainda em Desenvolvimento");
            rl.close;
            cliente.end();
        } else{
            rl.close();
            cliente.end();  // Close the client connection for invalid input
        } 
    });
}

function formatarData(data) {
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const ano = data.getFullYear();
    const hora = String(data.getHours()).padStart(2, '0');
    const minuto = String(data.getMinutes()).padStart(2, '0');

    return `${dia}/${mes}/${ano} ${hora}:${minuto}`;
}
connectClient();
escolha();
